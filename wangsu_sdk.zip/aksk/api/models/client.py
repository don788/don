# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
class Client:
    def __init__(self):
        pass
