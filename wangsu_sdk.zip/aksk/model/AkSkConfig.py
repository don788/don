class AkSkConfig:
    def __init__(self):
        self.access_key = None
        self.secret_key = None
        self.uri = None
        self.end_point = None
        self.method = None
        self.signed_headers = None
        self.custom_headers = {}
