import json
from auth.AkSkAuth import AkSkAuth
from model.AkSkConfig import AkSkConfig
from api.models.models import *


class Client:
    @staticmethod
    def main():
        prefetchRequest = PrefetchRequest()
        
        aksk_config = AkSkConfig()
        aksk_config.access_key = "{accessKey}"
        aksk_config.secret_key = "{secretKey}"
        aksk_config.end_point = "open.chinanetcenter.com"
        aksk_config.uri = "/ccm/fetch/ItemIdReceiver"
        aksk_config.method = "POST"

        # See AkSkAuth class for more methods, you can edit
        response = AkSkAuth.invoke(aksk_config, json.dumps(prefetchRequest.to_map()))
        print(response)


if __name__ == "__main__":
    Client.main()
